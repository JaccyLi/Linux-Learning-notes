#!/bin/bash
#
#*******************************************************************************
#Author:			steveli
#QQ:				1049103823
#Data:			    2019-09-24
#FileName:		    colorful.sh
#URL:		        https://blog.csdn.net/YouOops
#Description:		Test scrpting.
#Copyright (C):	    2019 All rights reserved
#*******************************************************************************
#!/bin/bash

chars="Please wait!"

while :; do
    j=0
  for (( i=0; i<${#chars}; i++ )); do
    sleep 0.15
    echo -en "\e[1;;42m  \e[0m\e[1;32m${chars[@]:$j}\e[0m" "\r"
    let j+=1
  done
done

unset chars
