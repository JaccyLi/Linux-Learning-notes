#!/bin/bash
#
#*******************************************************************************
#Author:			steveli
#QQ:				1049103823
#Data:			    2019-10-10
#FileName:		    checkdisk.sh
#URL:		        https://blog.csdn.net/YouOops
#Description:		checkdisk.sh
#Copyright (C):	    2019 All rights reserved
#*******************************************************************************
#Fontcolor#red(31):green(32):yellow(33):blue(34):purple(35):cyan(36):white(37)
#Backcolor#red(41):green(42):yellow(43):blue(44):purple(45):cyan(46):white(47)
#*******************************************************************************
#

D_MAX=`df -h | grep -E /dev/\(sd\|nvme\) | egrep -o "[0-9]{,3}%" | cut -d% -f1 | sort -nr | head -n1`
I_MAX=`df -hi | grep -E /dev/\(sd\|nvme\) | egrep -o "[0-9]{,3}%" | cut -d% -f1 | sort -nr | head -n1` 
THREAD_D=85
THREAD_I=85

if [[ $D_MAX -gt $THREAD_D ]]; then 
    echo -e "\e[1;31mWarning!\nThe disk space is almost full.\e[0m"
elif [[ $I_MAX -gt $THREAD_I ]]; then
    echo -e "\e[1;31mWarning!\nThe inode is almost full.\e[0m"
    
else
    echo -e "\e[1;32mNice.\e[0m"
    exit 0
fi

unset D_MAX
unset I_MAX
unset THREAD_D
unset THREAD_I
