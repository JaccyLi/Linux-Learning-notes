#!/bin/bash
#
#*******************************************************************************
#Author:			steveli
#QQ:				1049103823
#Data:			    2019-10-09
#FileName:		    sumfile.sh
#URL:		        https://blog.csdn.net/YouOops
#Description:		Test scrpting.
#Copyright (C):	    2019 All rights reserved
#*******************************************************************************

DIR=`find -L /var/ /etc/ /usr/ -maxdepth 1 -type d | wc -l`
FILE=`find -L /var/ /etc/ /usr/ -maxdepth 1 -type f | wc -l`
echo "The total is : $(( $DIR+$FILE-3 ))"
echo "The dirnum is : $(( $DIR-3 ))"
echo "The filenum is : $(( $FILE ))"

