#!/bin/bash
#
#*******************************************************************************
#Author:			steveli
#QQ:				1049103823
#Data:			    2019-10-06
#FileName:		    hostping.sh
#URL:		        https://blog.csdn.net/YouOops
#Description:		Test scrpting.
#Copyright (C):	    2019 All rights reserved
#*******************************************************************************

IP="\b(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\b" 
if [[ $1 =~ $IP ]]; then
    ping -W1 -c1 $1 &> /etc/null
    if [[ $? -eq 0 ]]; then
        echo -e "\e[1;32mThe host is up.\e[0m" 
    else
        echo -e "\e[1;35mThe host is down!\e[0m"
    fi
else 
    echo "It is not a legal ip, please check your input."

fi

unset IP
