#!/bin/bash
#
#*******************************************************************************
#Author:			steveli
#QQ:				1049103823
#Data:			    2019-10-11
#FileName:		    run.sh
#URL:		        https://blog.csdn.net/YouOops
#Description:		run.sh
#Copyright (C):	    2019 All rights reserved
#*******************************************************************************
#Fontcolor#red(31):green(32):yellow(33):blue(34):purple(35):cyan(36):white(37)
#Backcolor#red(41):green(42):yellow(43):blue(44):purple(45):cyan(46):white(47)
#*******************************************************************************
#

COLOR=$(($RANDOM%7+30))

while sleep 0.001; do
    echo -n " "
    echo -en "\e[1;${COLOR};${COLOR}m0 \e[0m"
    for((i=1 ; i<=$BLANK ; i++)); do
        echo -n " "
    done
    BLANK=$(($RANDOM%7+30))
    echo -en "\e[1;${COLOR};${COLOR}m 1\e[0m"
    for((i=1 ; i<=$BLANK ; i++)); do
        echo -n " "
    done
done
